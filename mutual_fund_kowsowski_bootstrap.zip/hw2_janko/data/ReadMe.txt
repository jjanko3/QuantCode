Mutual Fund Data Read Me

�mfr.dat�

The mutual fund return data is a matrix of dimension [336,3717], with the first column yyyymm, and then each column for a different fund.  

Fund return is in percent per month.

�-99� denotes values that are unavailable.

The sample screening, based on the CRSP mutual fund database, is described in Section 2 of Ferson and Chen (2015, Working Paper). In that paper, we require each fund to have at least 8 monthly return observations to perform fund-level analysis. 



