clear;
clc;
%set this to the path of the data
data_directory = '/home/jjanko/Documents/MATLAB/hw2_janko/data';
%set this to the path of the results directory
results_directory = '/home/jjanko/Documents/MATLAB/hw2_janko/results';
%set this to the path of the writeup directory
writeup_directory = '/home/jjanko/Documents/MATLAB/hw2_janko/writeup';
%get the data for the project and name the variables

mfr = readmatrix(fullfile(data_directory, 'mfr.dat'));

disp('Problem 2')
disp("The number of funds in mfr.dat")
disp("There should be 3,716")
disp(length(mfr(1,2:length(mfr(1,:)))))
mfr = mfr(:,2:length(mfr(1,:)));

[T,N] = size(mfr);
mfr(mfr == -99.) = NaN;

ff5 = fullfile(data_directory, 'cleaned_data_part2.csv');
factors = readmatrix(ff5);
rf = factors(:,length(factors(1,:)));
factors = factors(:, 2:length(factors(1,:)) -1);

[Tfactors, K] = size(factors);

MKT_b = containers.Map();
HML_b = containers.Map();
SMB_b = containers.Map();
int_b = containers.Map();
saved_residuals = containers.Map();
savedCoef = containers.Map();
alpha = containers.Map();
tstat = containers.Map();
alpha_sim = containers.Map();
tstat_sim = containers.Map();

for i = 1:N
    idx = find(isnan(mfr(:,i)) == 0);
    fund_i = mfr(idx,i);
    length_i = length(fund_i);
    if length_i > 8
        Mkt_RF = factors(idx,1);
        SMB = factors(idx,2);
        HML = factors(idx,3);
        RF = rf(idx,:);
        intercept = ones(length_i,1);
        excessR = fund_i - RF;
        MKT_b(string(i)) = Mkt_RF;
        SMB_b(string(i))= SMB;
        HML_b(string(i))= HML;
        int_b(string(i))= intercept;
        x = [Mkt_RF, SMB, HML, intercept];
        %get the alphas and the residuals
        [params,Resid,Hetero_SE,Hetero_tstat]=janko_ols(excessR,x);
        alpha(string(i)) = params(4);
        saved_residuals(string(i)) = Resid;
        tstat(string(i)) = Hetero_tstat(4);
        savedCoef(string(i)) = params;
        alpha_sim(string(i)) = [];
        tstat_sim(string(i)) = [];
    end
end
    
%%Kosowski method
k = keys(saved_residuals) ;
for sim = 1:1000
    for i = 1:length(saved_residuals)
        res_i = saved_residuals(k{i});
        lenr = length(res_i);
        T_b = randi([1,lenr],lenr,1);
        intercept_b = ones(lenr,1);
        res_b = res_i(T_b);
        c = savedCoef(k{i});
        pseudoR = c(1) * MKT_b(k{i}) + c(2) * SMB_b(k{i}) + c(3) * HML_b(k{i})+c(4) + res_b;
        x =   [MKT_b(k{i}), SMB_b(k{i}), HML_b(k{i}), intercept_b];
        %estimate alpha from bootstrapped return
        [params,Resid,Hetero_SE,Hetero_tstat]=janko_ols(pseudoR,x);
        a = params(4);
        t = Hetero_tstat(4);
        alpha_sim(k{i}) = [alpha_sim(k{i}); a];
        tstat_sim(k{i}) = [tstat_sim(k{i}); t];
    end
    
end

k = keys(alpha);
alpha_values = [];
for i = 1:length(k)
    alpha_values = [alpha_values; alpha(k{i})];
end
pcrtile_check = [1 5 10 25 50 75 90 95 99];
p_check = prctile(alpha_values,pcrtile_check,'all');
output = [];
 
for p=1:length(p_check)

 alpha_array = [];
 tstat_array = [];
 sim_alpha_array = [];
 pct_array = [];
 
 for i = 1:length(alpha_values)
     if p == 1
         if  alpha_values(i) <= p_check(p)  
             alpha_array = [alpha_array; alpha(k{i})];
             tstat_array = [tstat_array; tstat(k{i})];
             sim_alpha_array = [sim_alpha_array; mean(alpha_sim(k{i}))];
             pct_array = [pct_array; length(find(tstat_sim(k{i}) > 1.96)) / length(tstat_sim(k{i}))];
             
         end
     end
     if p~=1 && p ~= length(p_check)
         if  alpha_values(i) > p_check(p-1) && alpha_values(i) <= p_check(p)
             alpha_array = [alpha_array; alpha(k{i})];
             tstat_array = [tstat_array; tstat(k{i})];
             sim_alpha_array = [sim_alpha_array; mean(alpha_sim(k{i}))];
             pct_array = [pct_array; length(find(tstat_sim(k{i}) > 1.96)) / length(tstat_sim(k{i}))];
         end
     end

     if p == length(p_check)
         if  alpha_values(i) > p_check(p)  
             alpha_array = [alpha_array; alpha(k{i})];
             tstat_array = [tstat_array; tstat(k{i})];
             sim_alpha_array = [sim_alpha_array; mean(alpha_sim(k{i}))];
             pct_array = [pct_array; length(find(tstat_sim(k{i}) > 1.96)) / length(tstat_sim(k{i}))];
         end
     end
 end
 output = [output; [pcrtile_check(p) length(alpha_array) mean(alpha_array) mean(tstat_array) mean(sim_alpha_array) mean(pct_array)]];

end

part2_out = array2table(output);
part2_out.Properties.VariableNames  = {'Percentile' 'Nobs' 'Alpha' 't-stat', 'Sim-Alpha', '% > 1.96'};
writetable(part2_out, fullfile(results_directory, 'part_2.csv'),'WriteRowNames',true);

