clear all; close all; clc;
%set this to the path of the data
data_directory = '/home/jjanko/Documents/MATLAB/hw2_janko/data';
%set this to the path of the results directory
results_directory = '/home/jjanko/Documents/MATLAB/hw2_janko/results';
%set this to the path of the writeup directory
writeup_directory = '/home/jjanko/Documents/MATLAB/hw2_janko/writeup';
%get the data for the project and name the variables

mfr = readmatrix(fullfile(data_directory, 'mfr.dat'));
factors = readmatrix(fullfile(data_directory, 'cleaned_data_part4.csv'));
%separate the risk free rate from the factors
rf = factors(:,length(factors(1,:)));
factors = factors(:, 1:length(factors(1,:)) -1);

intercept = ones(length(factors(:,1)),1);
factors = [factors intercept];

disp('Problem 4')
disp("The number of funds in mfr.dat")
disp("There should be 3,716")
disp(length(mfr(1,2:length(mfr(1,:)))))


%get the date column
date = mfr(:,1);
%get the actual mutual fund data outside of date
mf_data = mfr(:,2:length(mfr(2,:)));
fmb = [];
stage1= [];
t = [];
% get the ff5 and liquidty data on the same time frame
for i = 1:length(date)
    if i >= 25
        
        %step 1
        cross_section = [];
        %add an extra lag for t-1
        factor_t = factors(i-24:i-1, 2:length(factors(1,:)));
        for j = 1:length(mf_data(1,:))
            %get the rolling window for each mutual fund
            mut = mf_data(i-24:i-1,j);
            %check to see we have return observations over the whole window
            if sum(mut == -99) == 0
                y = mut - rf(i-24:i-1,:);
                x = factor_t;
                [params,Resid,se,tstat, r2_stage1]=janko_ols(y,x);
                cross_section = [cross_section; [mf_data(i,j); params]'];
            end
        end
        %step 2 do the regression on the cross section
        if length(cross_section) > 2
            y = cross_section(:,1);
            x = cross_section(:,2:length(cross_section(1,:)));
            [params,Resid,se,tstat, r2_stage2]=janko_ols(y,x);
            stage1 = [stage1; [date(i) round(mean(x),4) round(r2_stage1,4)]];
            fmb = [fmb; [date(i); round(params,4); round(r2_stage2,4)]'];
            t = [t; [date(i) mean(x) ./ (std(x) / sqrt(24.))]];
        end
        
    end
    
end

part4_out1 = array2table(stage1);
part4_out1.Properties.VariableNames  = {'Date', 'Liq','Mkt-RF','SMB','HML','intercept','r2 stage 1' };
writetable(part4_out1, fullfile(results_directory, 'part_4_first_stage_all.csv'),'WriteRowNames',true);

part4_out = array2table(fmb);
part4_out.Properties.VariableNames  = {'Date', 'Liq','Mkt-RF','SMB','HML','intercept','r2 stage 2' };
writetable(part4_out, fullfile(results_directory, 'part_4_second_stage_all.csv'),'WriteRowNames',true);

part4_out = array2table(t);
part4_out.Properties.VariableNames  = {'Date', 'Liq','Mkt-RF','SMB','HML','intercept' };
writetable(part4_out, fullfile(results_directory, 'part_4_t_stat.csv'),'WriteRowNames',true);



pooled_stage1 = mean(stage1(:,2:length(stage1(1,:))));
pooled_stage2 = mean(fmb(:,2:length(fmb(1,:))));
pooled_t = mean(t(:,2:length(t(1,:))));

part4_out1 = array2table(pooled_stage1);
part4_out1.Properties.VariableNames  = {'Liq','Mkt-RF','SMB','HML','intercept','r2 stage 1' };
writetable(part4_out1, fullfile(results_directory, 'part_4_first_stage_pooled.csv'),'WriteRowNames',true);

part4_out = array2table(pooled_stage2);
part4_out.Properties.VariableNames  = {'Liq','Mkt-RF','SMB','HML','intercept','r2 stage 2' };
writetable(part4_out, fullfile(results_directory, 'part_4_second_stage_pooled.csv'),'WriteRowNames',true);

part4_out = array2table(pooled_t);
part4_out.Properties.VariableNames  = {'Liq','Mkt-RF','SMB','HML','intercept' };
writetable(part4_out, fullfile(results_directory, 'part_4_t_pooled.csv'),'WriteRowNames',true);


